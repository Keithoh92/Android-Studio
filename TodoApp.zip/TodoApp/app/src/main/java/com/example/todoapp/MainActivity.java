package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements onClickListener{

    private static final int REQ_CODE = 1234;
    String[] todoArray = {"List items appear here"};

    TextView topLabel;
    Button create, edit;
    MySQLiteHelper dbHelper;
    ListView lv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new MySQLiteHelper(this);
        topLabel = (TextView) findViewById(R.id.label);
        create = (Button) findViewById(R.id.createButton);
        edit = (Button) findViewById(R.id.editButton);

//        ArrayList<String> nameArray = new ArrayList<>();
//        ArrayList<String> infoArray = new ArrayList<>();
        String[] nameArray1 = {};
        String[] infoArray1 = {};

        //Creates listView in mainActivity
        //Loads any lists that exist in database
        List<MyList> lists = dbHelper.findAllLists();
        if (lists.isEmpty()) {
            showMessage("Error", "No records found");
            return;
        }
        //for (MyList list : lists) {


        //StringBuffer buffer = new StringBuffer();
        for (MyList list : lists) {
            //buffer.append("id: " + list.get_id() + "\n");
//            buffer.append("Name: " + list.getName() + "\n");
//            buffer.append("List: " + list.getLists() + "\n\n");
            nameArray1 = new String[]{list.getName()};
            infoArray1 = new String[]{list.getLists()};

        }

        //buffer.toString();
        //list2.add(buffer.toString());

        //showMessage("List Details", buffer.toString());
        //ArrayList<>
//        String[] nameArray1 = {""};
//        String[] infoArray1 = {""};
        //nameArray1

        CustomListAdapter myAdapter = new CustomListAdapter(this, nameArray1, infoArray1);
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.simple_list_item_1, list2);
        //lv = (ListView)findViewById(R.id.todo_list);
        ListView listView = (ListView) findViewById(R.id.todo_list);
        listView.setAdapter(myAdapter);

    }
    public void onPause() {
        super.onPause();
        Log.d("testing", "onPause got called");
    }

    public void onResume() {
        super.onResume();
        Log.d("testing", "onResume got called");
    }

    public void onStart() {
        super.onStart();
        Log.d("testing", "onStart got called");
    }

    public void onStop() {
        super.onStop();
        Log.d("testing", "onStop got called");
    }

    public void onDestroy() {
        super.onDestroy();
        Log.d("testing", "onDestroy got called");
    }
    //Create List activate second activity
    public void onClick(View view){
        Intent createIntent = new Intent(this, MainActivity2.class);

        if(createIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(createIntent, REQ_CODE);
        }
        // Code to retrieve list info***********************************

    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode==REQ_CODE && resultCode == RESULT_OK){
            String newName = intent.getStringExtra("the_name");
            String newList = intent.getStringExtra("new_list");

            dbHelper.addList(new MyList(newName, newList));

        }
    }


        public void showMessage(String title,String message)
        {
            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(message);
            builder.show();
        }

}