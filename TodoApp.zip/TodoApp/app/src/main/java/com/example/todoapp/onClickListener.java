package com.example.todoapp;

public interface onClickListener {
}
