package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class MainActivity2 extends AppCompatActivity{

    private EditText topLabel2, createList;
    private Button save;
    MySQLiteHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        save=(Button)findViewById(R.id.saveButton);
        //Intent intent = getIntent();
        //save.setOnClickListener((View.OnClickListener) this);

    }
    public void onClickSave(View view){
        topLabel2=findViewById(R.id.editLabel2);
        createList=findViewById(R.id.insertList);

            String name = topLabel2.getText().toString();
            String newList = createList.getText().toString();
            Intent intent = new Intent();
            intent.putExtra("the_name", name);
            intent.putExtra("new_list", newList);
            setResult(RESULT_OK, intent);
            finish();
//
//            topLabel2.getText().toString();
//            createList.getText().toString();

            //dbHelper.addList(new MyList(topLabel2.getText().toString(), createList.getText().toString()));
            //showMessage("Success", "List added");
            //finish();

    }


}